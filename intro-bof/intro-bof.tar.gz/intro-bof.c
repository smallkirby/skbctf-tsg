#include<stdio.h>
#include<stdlib.h>

void show_flag(void) {
  FILE *flag = fopen("./flag", "r");
  char fbuffer[0x50] = {0};

  if (flag == NULL) {
    puts("[ERROR] failed to open flag file.");
    exit(1);
  }
  fread(fbuffer, 0x50, 1, flag);
  printf("%s\n", fbuffer);
}

void show_stack(unsigned long base) {
  for (unsigned ix = 0; ix != 20; ++ix) {
    unsigned long target = base + ix * 8;
    printf("| 0x%lx | ", target);
    printf("%016lx | ", *(unsigned long *)target);
    for (int jx = 0; jx != 8; ++jx) {
      char c = *(char *)(target + jx);
      if (c < 0x20 || c > 0x7E) c = 0x20;
      printf("%c", c);
    }
    printf("| ");
    if (ix == 0)  printf("<-- name[0x20]");
    if (ix == 5)  printf("<-- canary");
    if (ix == 6) printf("<-- old RBP value");
    if (ix == 7) printf("<-- RETURN ADDRESS (__libc_start_main)");
    puts("");
  }
}

void init(void) {
  setvbuf(stdout, NULL, _IONBF, 0);
  setvbuf(stdin, NULL, _IONBF, 0);
  setvbuf(stderr, NULL, _IONBF, 0);
}

int main(void) {
  init();
  char name[0x20];

  puts("Welcome to introduction series!");
  puts("                 BOF: Buffer Overflow attack\n");

  puts("1. C program can read user-input for example by 'scanf()'.");
  puts("-------------------------------");
  puts("\tchar name[0x50];");
  puts("\tprintf(\"> \");");
  puts("\tscanf(\"%%s\\n\", name);");
  puts("\tprintf(\"your name: %s\\n\", name);");
  puts("-------------------------------");

  printf("> ");
  scanf("%s", name);
  printf("you name: %s\n", name);

  puts("\n");
  puts("2. program running on x64 architecture has its return value on stack.");
  puts("Now, stack looks like below: ");
  puts("----------------------------------------------");
  show_stack((unsigned long)name);
  puts("----------------------------------------------");

  puts("\nIf you overwrite this RETURN ADDRESS, the program would jump to the addr you write on it.\n\n");

  puts("3. I have a gift for you.");
  puts("-------------------------------");
  puts(R"(void show_flag(void) {
  FILE *flag = fopen("./flag.txt", "r");
  char fbuffer[0x50] = {0};

  if (flag == NULL) {
    puts("[ERROR] failed to open flag file.");
    exit(1);
  }
  fread(fbuffer, 0x50, 1, flag);
  printf("%s\n ", fbuffer);
})");
  puts("-------------------------------");

  printf("This function is located @ %p\n", show_flag);

  puts("\n\n\n");

  puts("<<< Now, time to exploit! >>>");
  puts("I re-run below code.");
  puts("-------------------------------");
  puts("\tchar name[0x50];");
  puts("\tprintf(\"> \");");
  puts("\tscanf(\"%%s\\n\", name);");
  puts("\tprintf(\"your name: %s\\n\", name);");
  puts("-------------------------------");

  puts("\nYour missions is:");
  puts(" A: overwrite RETURN ADDRESS with 'show_flag()' addr.");
  puts("  You can input more than 0x20 chars in 'scanf()'.");
  puts(" B: avoid changing canary value.");
  puts("  Program crashes when it finds that canary has been changed.");

  puts("\n\n << GO >>\n");
  printf("> ");
  scanf("%s", name);
  printf("you name: %s\n", name);

  puts("\n\nHere is a result of stack.");
  puts("----------------------------------------------");
  show_stack((unsigned long)name);
  puts("----------------------------------------------");

  puts("\n\n I hope you can get a flag... BYE\n");

  return 0;
}